export * from './editar-enfermo.component';
