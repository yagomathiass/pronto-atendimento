import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AtendimentoService } from './shared';
import { ListarEnfermosComponent } from './listar';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CadastrarEnfermoComponent } from './cadastrar';
import { EditarEnfermoComponent } from './editar/editar-enfermo.component';


@NgModule({
  declarations: [
    ListarEnfermosComponent,
    CadastrarEnfermoComponent,
    EditarEnfermoComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule
  ],
  providers: [
    AtendimentoService
  ],
})
export class ClinicaModule { }
