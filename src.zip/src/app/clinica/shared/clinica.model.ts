export class Cadastro {
    constructor(
        public id?: number,
        public nome?: string,
        public prioridade?: string,
        public atendido?: boolean

    ) {

    }
}