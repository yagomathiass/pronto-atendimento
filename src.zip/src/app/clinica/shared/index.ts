export * from './clinica.model';
export * from './atendimento.service';
export * from '../listar';
export * from './cadastro-atendido.directive';
