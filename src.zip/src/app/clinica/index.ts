export * from './clinica.module';
export * from './shared';
export * from './clinica-routing.module';
export * from './listar';
export * from './cadastrar';
export * from './editar';
