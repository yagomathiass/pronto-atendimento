export * from './cadastrar-enfermo.component';
