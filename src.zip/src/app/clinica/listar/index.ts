export * from './listar-enfermos.component';
