import { Component, OnInit } from '@angular/core';
import { AtendimentoService, Cadastro } from '../shared';

@Component({
  selector: 'app-listar-enfermos',
  templateUrl: './listar-enfermos.component.html',
  styleUrls: ['./listar-enfermos.component.css']
})


export class ListarEnfermosComponent implements OnInit {

  cadastro: Cadastro[];

  constructor(private atendimentoService: AtendimentoService) { }

  ngOnInit(){
    this.cadastro = this.listarTodos();
  }

  listarTodos(): Cadastro[]{
    return this.atendimentoService.listarTodos();
  }

  alterarStatus(cadastro:Cadastro) : void {
    if(confirm('Deseja alterar o status da tarefa " '+ cadastro.nome +' "? ')){
      this.atendimentoService.alterarStatus(cadastro.id);
      this.cadastro = this.listarTodos();
    } else {
      this.cadastro = this.listarTodos();
    }
  }

  remover($event: any, enfermo: Cadastro): void{
    $event.preventDefault();
    if(confirm('Deseja remover a tarefa " '+ enfermo.nome +' "? ')){
      this.atendimentoService.remover(enfermo.id);
      this.cadastro = this.listarTodos();
    } else {
      this.cadastro = this.listarTodos();
    }
  }

}
